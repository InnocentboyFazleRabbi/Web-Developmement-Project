<?php
	require('classes/databaseConnectionClass.php');
	
	class dbCheck extends databaseConnection{
		
		public function database_check(){
			///print_r($this->connect);
			$connt = $this->connect;
			if(!$connt->connect_error){
				echo '<h1 align="center" style="color:green; border:5px solid green;">Hurray Database Connect Successfully</h1>';
				echo '<h1 id="counter" align="center" style="font-size:10rem; padding:25px; border:10px solid #FFC107; max-width:200px; border-radius:50%; margin:auto;">1</h1>';
				header('Refresh:9;url=index.php');
				$connt->close();
			}else{
				die('Database Connection Error: '.$connt->connect_error);
				
			}
		}
	}
	
	
	$check = new dbCheck;
	$check->database_check();
?>

<script>
// Set the date we're counting down to
var countDownDate = new Date();
countDownDate.setSeconds(countDownDate.getSeconds()+10);
// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("counter").innerHTML = seconds;

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("counter").innerHTML = "EXPIRED";
  }
}, 1000);
</script>





