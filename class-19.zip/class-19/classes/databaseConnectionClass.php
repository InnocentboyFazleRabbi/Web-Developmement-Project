<?php
	
	require(__DIR__.'/../db_details.php');
	
	class databaseConnection{
		
		private $db_host = DB_HOST;
		private $db_user = DB_USER;
		private $db_pass = DB_PASS;
	    private $db_name = DB_NAME;
		protected $connect;
		
		public function __construct(){
			$this->db_connection();
		}
		private function db_connection(){
			return $this->connect = new mysqli($this->db_host,$this->db_user,$this->db_pass,$this->db_name);
		}
		
	}

		
?>







