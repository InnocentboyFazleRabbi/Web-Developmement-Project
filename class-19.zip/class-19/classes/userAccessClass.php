<?php

require_once('databaseConnectionClass.php');

class userAccess extends databaseConnection{
	public function userLogin($data){
		$email =$data['email'];
		$password =$data['password'];
		
		if(empty($email) || empty($password)){
			echo '<h1 align="center">Email/Password does not empty</h1>';
		}else{
			///// Database Connection /////
			$db_connt = $this->connect;
			
			$sql_query="SELECT * FROM user WHERE email='$email' && password='$password'";
			
			$result = $db_connt->query($sql_query);
			if($result == true){
				if($result->num_rows == 1){
					while($userData = $result->fetch_assoc()){
						$userName = $userData['name'];
						$userEmail = $userData['email'];
					}
					/// Session Actions ///
					$_SESSION['userName']=$userName;
					$_SESSION['userEmail']=$userEmail;
					$_SESSION['loginAsi']=1;
					
					/// Cookie Actions ///
					if(isset($data['remember'])){
						setcookie('userEmail',$email,time()+5*60,'/');
						setcookie('userPass',$password,time()+5*60,'/');
					}else{
						setcookie('userEmail','',time()+0,'/');
						setcookie('userPass','',time()+0,'/');
					}
					header('Location: dashboard/dashboard.php');
					
					echo 'Dash Board Koi?';
				}else{
					echo '<h1 align="center">Email/Password is invalid</h1>';
				}
			}else{
				echo 'Error: '.$db_connt->error;
			}
			$db_connt->close();
		}
		
	}/// userLogin method ///
	
	public function userLogout(){
		session_destroy();
		session_unset();
		header('Location: ../index.php');
	}
}/////	userAccess Class /////

	
?>







