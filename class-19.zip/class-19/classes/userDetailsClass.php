<?php

require_once('databaseConnectionClass.php');

class userDetails extends databaseConnection{
	
	public function profileData($data){
		
		///// Database Connection /////
		$db_connt = $this->connect;
			
		$sql_query="SELECT * FROM user WHERE email='$data'";
			
		$result = $db_connt->query($sql_query);
		if($result == true){
			if($result->num_rows == 1){
				return $result;
					
			}else{
				echo '<h1 align="center">Data Connection Invalid</h1>';
			}
		}else{
			echo 'Error: '.$db_connt->error;
		}
			$db_connt->close();
		
	}/// profileData method ///
	
	public function profileImage($data){
		
		
		
		$destination ='images/userAvatar';
		if(!is_dir('../'.$destination)){
			mkdir('../'.$destination);
		}
		$imageName=$data['image']['name'];
		$imageTmp=$data['image']['tmp_name'];
		$imageSize=$data['image']['size'];
	
		########## Use Selected files upload only ######
		$fileExtension = strtolower(pathinfo($imageName,PATHINFO_EXTENSION));
		/////echo $imageName.'<br>';
		/////echo $fileExtension.'<br>';
		/////$selectedFile = array('pdf','docx');
		
		$newFileName= uniqid().'-'.$_SESSION['userEmail'].'.'.$fileExtension;
		
		/////if(in_array($fileExtension,$selectedFile)){
		/////	move_uploaded_file($imageTmp,'../'.$destination.'/'.$newFileName);
		/////}else{
		/////	echo 'hoy nai';
		/////}
		########## Not user #############
		/////$act =explode('.',$imageName);
		/////print_r(explode('.',$imageName));
		/////echo '<br>';
		/////echo end($act).'<br>';
		
		$checkImage = getimagesize($imageTmp);
		if($checkImage == true){
			/// image size checking
			if($imageSize < 1048576){
				//echo $imageSize;
				///// Database Connection /////
				$db_connt = $this->connect;
					
				$sql_query="SELECT * FROM user WHERE email='$_SESSION[userEmail]'";
					
				$result = $db_connt->query($sql_query);
				///image searching ///
				while($image= $result->fetch_assoc()){
					$getImageData = $image['image'];
				}
				if($getImageData != ''){
					//// File Removing Part ////
					if(file_exists('../'.$destination.'/'.$getImageData)){
						unlink('../'.$destination.'/'.$getImageData);
					}else{
						echo 'Unknown Error';
					}
					
				}
				
				$uploadImage= move_uploaded_file($imageTmp,'../'.$destination.'/'.$newFileName);
					
					if($uploadImage == true){
						$sql_update ="UPDATE user SET image='$newFileName' WHERE email='$_SESSION[userEmail]'";
						$updateResult = $db_connt->query($sql_update);
						if($db_connt->error){
							die('table error: '.$db_connt->error);
						}else{
							echo 'Image upload successfully';
							header('Refresh:1;url= profile.php');
							$db_connt->close();
						}
					}
				
				
			}else{
				echo 'Sorry, Image size will be maximum 1mb';
			}
			
		}else{
			echo 'hay hay ata to image na';
		}
		
		///echo '<pre>';
		///print_r($data);
		///
		///echo '</pre>';
	}
	
}/////	userAccess Class /////

	
?>







