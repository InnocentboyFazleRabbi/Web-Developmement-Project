<?php
	include('header.php');
?>
<div class="container pt-5">
	<h1 class="h2">Dashboard</h1>
	<div class="row">
		<div class="col">
		<?php
		while($u_data = $user_details->fetch_assoc()){
			?>
			<div class="card bg-light">
				<div class="card-header">
					<p class="display-4">Hello, <?php echo $u_data['name'];  ?></p>
				</div>
				<div class="card-body">
					<?php echo date('d/m/Y h:i:s l'); ?>
				</div>
			</div>

			<?php
		}

		?>
		</div>
	</div>
</div>


<?php
	include('footer.php');
?>