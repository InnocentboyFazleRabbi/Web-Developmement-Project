<?php

	class studenData{
		
		public $student_name = 'Md. Sharif Ullah Sarkar';
		protected $student_email = 'manikbd.888@gmail.com';
		private $student_age = 32;
		
		
		
		public function studentDetails($a,$b){
			echo $a;
			echo $b;
			
			echo $this->student_name= $a;
			//echo $this->student_email;
			echo time();
			echo $this->studentPayment();
			
		}
		protected function studentPayment(){
			echo '1200tk';
		}
		
	}
/////////// object /////////////////////
	$studentData = new studenData;
	
	
	echo '<br>';
	echo $studentData->studentDetails('Manik Sarkar','mainksarkar@gmail.com');
	echo '<br>';
	echo $studentData->student_name;
	echo '<br>';
	echo $studentData->student_email;
	echo '<br>';
	echo $studentData->student_age;
	echo '<br>';
	

?>