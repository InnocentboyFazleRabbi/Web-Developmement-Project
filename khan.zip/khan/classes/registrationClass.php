<?php

require_once('databaseConnectionClass.php');

class Registration extends databaseConnection{
	
	public function user_registration($data){
		
		#### All Form Data #####
		$name = $data['name'];
		$email = $data['email'];
		$phone = $data['phone'];
		$blood = $data['blood'];
		$gender = $data['gender'];
		$password = $data['password'];
		$cpassword = $data['cpassword'];
		$accept = $data['accept'];
		$error = '';
		/// Name Validation ///
		if(strlen($name) < 3 || str_word_count($name) < 2 || !preg_match('/^[-a-zA-Z. ]*$/',$name)){
			$error .= 'Your Name Must Be in minimum 3 Letter and 2 Words <br>';
		}
		/// Email Validation ///
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$error .= 'Please send your valid email <br>';
		}
		/// Phone Validation ///
		if(strlen($phone) < 11 || strlen($phone) > 14 || !preg_match('/^[0-9 ]*$/',$phone)){
			$error .= 'Please send your valid phone number <br>';
		}
		/// Blood Group Validation ///
		$bloodCollection = array('apv','anv','bpv','bnv','opv','onv','abpv','abnv');
		if(!in_array($blood,$bloodCollection)){
			$error .= 'Sorry you are an Alien <br>';
		}
		/// Gender Validation ///
		$genderCollection = array('m','f');
		if(!in_array($gender,$genderCollection)){
			$error .= 'We did not identify your health <br>';
		}
		/// Password Validation ///
		if(strlen($password) > 5 && strlen($password) < 50){
			if($password != $cpassword ){
				$error .= 'Password & Confirm Password Does not Match <br>';
			}
			
		}else{
			$error .= 'Password Length will be in 6-50 character <br>';
		}
		
		if($error != ''){
			echo '<div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
				  <strong>Sorry!</strong> Your have some errors in this form. Which are-<br>
				  '.$error.'
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				  </button>
				</div>';
			
		}else{
			/// Database Connection ///
			$db_connt = $this->connect;
			
			$sql_query = "INSERT INTO user(name, email, phone, blood, gender, password) VALUES ('$name', '$email', '$phone', '$blood', '$gender', '$password')";
			
			if($db_connt->query($sql_query)){
				echo '<div class="alert alert-success alert-dismissible fade text-center show" role="alert">
						  <strong>Congratulation!</strong> Your Form Saved Successfully.
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						  </button>
						</div>';
				header("Refresh:3; url=index.php");
			}else{
				echo '<h3 align="center">Inserting Problem '.$db_connt->error.'</h3> align="center"';
				header("Refresh:1; url=index.php");
			}
			
			
			$db_connt->close();
			
		}

			
	}/// user_registration method ///
	
}//// Registration Class /////


	
?>







