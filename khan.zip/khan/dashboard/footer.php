			</main>
<!-- Main Content Part End -->		  
			</div>
		</div>
		
		<footer class="bg-secondary mt-auto">
			<div class="container py-3">
				<p class="text-white text-center mb-0">&copy; All Rights Reserved By Md. Sharif Ullah Sarkar</p>
			</div>
		</footer>
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../js/jquery-3.3.1.slim.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
	<script src="dashboard.js"></script>

</body> 
</html>