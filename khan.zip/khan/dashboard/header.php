<?php
	session_start();
	if($_SESSION['loginAsi'] != 1){
		header('Location: index.php');
	}
	if(!empty($_SESSION['userEmail'])){
		require_once('../classes/userDetailsClass.php');
		$userD = new userDetails;
		$user_details = $userD->profileData($_SESSION['userEmail']);
		//print_r($user_details);
	}
	if(isset($_POST['logout'])){
		require_once('../classes/userAccessClass.php');
		$logout = new userAccess;
		$logout->userLogout();
	}
?>

<!DOCTYPE html>
<html class="h-100">

     <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!--site name -->
		<title>Musfiq</title>
		
		<!--company icon -->
		<link rel="icon" href="images/favicon.ico" type="image/x-icon">
		
		<!--Fontawsome part -->
		<link rel="stylesheet" href="../css/all.css">
		
		<!--Stylesheet part -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- Custom styles for this template -->
		<link href="../dashboard.css" rel="stylesheet">
		

		<style>
			[id*="-error"]{
				color:yellow;
				float:left;
			}
		</style>
		<script rel="script" src="../js/jquery-3.3.1.min.js" ></script>
		<script rel="script" src="../js/custom.js" ></script>
     </head>
    <body class="d-flex flex-column h-100">
		<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
		  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Company name</a>
		  <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
		  <ul class="navbar-nav px-3">
			<li class="nav-item text-nowrap text-white">
			  <?php echo $_SESSION['userName']; ?>
			</li>
			<li class="nav-item text-nowrap">
			  <a class="nav-link" class="btn" onclick="document.getElementById('logout').submit()">Sign out</a>
			  <form id="logout" method="post">
				<input type="hidden" name="logout">
			  </form>
			</li>
		  </ul>
		</nav>

		<div class="container-fluid pt-5">
		  <div class="row">
			<nav class="col-md-2 bg-light sidebar pt-3">
			  <div class="sidebar-sticky">
				<ul class="nav flex-column">
				  <li class="nav-item">
					<a class="nav-link active" href="#">
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
					  Dashboard <span class="sr-only">(current)</span>
					</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="profile.php">
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
					  Profile
					</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
					  Products
					</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
					  Customers
					</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bar-chart-2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
					  Reports
					</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
					  Integrations
					</a>
				  </li>
				</ul>
			  </div>
			</nav>

<!-- Main Content Part -->
			<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 pt-5">
			
			
			
			