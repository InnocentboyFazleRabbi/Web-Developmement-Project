<?php
	
	include('header.php');
	
	if(isset($_POST['image-upload'])){
		$profilePic = $userD->profileImage($_FILES);
		
	}
?>
			
			<div class="container pt-2">
				<h1 class="h2">Profile</h1>
				<?php
					while($u_data = $user_details->fetch_assoc()){
						?>
				<div class="row mb-3 justify-content-center">
					<h5 class="bg-secondary text-white p-3 w-100">Upload Your Profile Picture</h5>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="card">
							<?php
							/*
								if($u_data['image'] != ''){
									echo '<img src="../images/userAvatar/'.$u_data['image'].'" class="card-img">';
								}else{
									echo '<img src="../images/userAvatar/avatar.png" class="card-img">';
								}
							*/
							?>
							<img src="../images/userAvatar/<?php if($u_data['image'] != ''){echo $u_data['image'];}else{echo 'avatar.png';}?>" class="card-img">
							
							<div class="card-footer">
								<form method="post" enctype="multipart/form-data">
								  <div class="form-group">
									<label for="image">Profile Image</label>
									<input name="image" type="file" class="form-control-file" id="image">
								  </div>
								  <button type="submit" name="image-upload" class="btn btn-outline-success w-100">Upload</button>
								</form>
							</div>
						</div>
					</div>
				</div>
				<h5 class="bg-secondary text-white p-3">My Details</h5>
				<dl class="row">
				  
						  <dt class="col-sm-3">Name</dt>
						  <dd class="col-sm-9"><?php echo $u_data['name'] ?></dd>

						  <dt class="col-sm-3">Email</dt>
						  <dd class="col-sm-9"><?php echo $u_data['email'] ?></dd>

						  <dt class="col-sm-3">Phone</dt>
						  <dd class="col-sm-9"><?php echo $u_data['phone'] ?></dd>

						  <dt class="col-sm-3">Blood</dt>
						  <dd class="col-sm-9"><?php 
							$blood = array('apv'=>'A+','anv'=>'A-','bpv'=>'B+','bnv'=>'B-','opv'=>'O+','onv'=>'O-','abpv'=>'AB+','abnv'=>'AB-',);
						
							foreach($blood as $bv => $bn){
								if($bv == $u_data['blood']){
									echo $bn;
								}
							}
						  
						  
						  
						  ?></dd>

						  

						<?php
					}
				  
				  ?>
				</dl>
			  </div>

<?php
	include('footer.php');
	ob_clean();
	ob_flush();
?>