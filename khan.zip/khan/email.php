<?php

if(isset($_GET['emailAction'])){
	
	$name = $_GET['name'];
	$email = $_GET['email'];
	$phone = $_GET['phone'];
	$message = $_GET['message']."\r\n";
	$message .= $_GET['name']."\r\n";
	$message .= $_GET['email']."\r\n";
	$message .= $_GET['phone']."\r\n";
	$sub = 'From my personal Website';
	
	$emailAction = mail('manikbd.888@gmail.com',$sub,$message,'From:'.$email);
	
	if($emailAction == true){
		echo 'Hurray Parsi';
	}else{
		echo 'Pore abar try korum';
	}
}else{
	echo '<h1 align="center">Page Not Found</h1>';
}


?>







