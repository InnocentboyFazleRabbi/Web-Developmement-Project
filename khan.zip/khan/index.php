<?php
	session_start();
	
	if(isset($_POST['login'])){
		require_once('classes/userAccessClass.php');
		$user_login = new userAccess;
		$login = $user_login->userLogin($_POST);
	}
?>

<!DOCTYPE html>
<html>

     <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!--site name -->
		<title>Musfiq</title>
		
		<!--company icon -->
		<link rel="icon" href="images/favicon.ico" type="image/x-icon">
		
		<!--Fontawsome part -->
		<link rel="stylesheet" href="css/all.css">
		
		<!--Stylesheet part -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
		

		<style>
			[id*="-error"]{
				color:yellow;
				float:left;
			}
		</style>
		<script rel="script" src="js/jquery-3.3.1.min.js" ></script>
		<script rel="script" src="js/custom.js" ></script>
     </head>
    <body>
	    <header>
			 <!--company name & logo-->
			 <!-- Image and text -->
			<div id="navbar">
				<nav class="navbar navbar-dark bg-transparent  navbar-expand-lg fixed-top ">
				  <a class="navbar-brand" href="#navbar">
					<img src="images/logo1.png" width="40" height="40" class="d-inline-block align-top" alt="site logo">
					<span class="h3 text-uppercase text-white">Musfiqur Rahman</span>
				  </a>
				  <button class="navbar-toggler bg-info" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon "></span>
				  </button>
				  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav ml-auto float-right">
					  <a class="nav-item nav-link active text-warning px-3 text-uppercase" href="#home">Home <span class="sr-only">(current)</span></a>
					  <a class="nav-item nav-link text-info  px-3 text-uppercase" href="#about">About</a>
					  <a class="nav-item nav-link text-info px-3 text-uppercase" href="#sevice">Sevice</a>
					  <a class="nav-item nav-link text-info  px-3 text-uppercase" href="#projects">Projects</a>
					  <a class="nav-item nav-link text-info  px-3 text-uppercase" href="#contact">Contact</a>
					  <a href="" class="nav-link px-3 text-uppercase btn btn-info text-white" data-toggle="modal" data-target="#loginModal">Login</a>
					</div>
				  </div>
				</nav>
			</div>
		</header>
<!-- Login Modal -->
<div class="modal fade" id="loginModal">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">LogIn</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<form method="post">
			  <div class="form-group">
				<label for="email">Email address</label>
				<input type="email" name="email" class="form-control" id="email" value="<?php if(!empty($_COOKIE['userEmail'])){ echo $_COOKIE['userEmail']; } ?>" placeholder="your email" required>
			  </div>
			  <div class="form-group">
				<label for="password">Password</label>
				<input type="password" name="password" class="form-control" id="password" value="<?php if(!empty($_COOKIE['userPass'])){ echo $_COOKIE['userPass']; } ?>"placeholder="Password" required>
			  </div>
			  <div class="form-group form-check">
				<input type="checkbox" name="remember" <?php if(!empty($_COOKIE['userEmail'])){ echo 'checked'; } ?> class="form-check-input" id="remember">
				<label class="form-check-label" for="remember">Remember Me</label>
			  </div>
			  <button type="submit" name="login" class="btn btn-primary">Submit</button>
			</form>
			<p class="text-primary float-right">New User <a class="text-danger" href="registration.php">Registration</a></p>
      </div>
    </div>
  </div>
</div>
		<main>
		       <!-- Slider part-->
			<section id="home">
				<div class="slider">
					<div class="container header-size">
						<div class="row">
							<!-- Content part-->
							<div class="col-6 col-custom">
								<p class="text-uppercase text-warning">Introduction</p>
								<h6 class="text-uppercase text-white">Hello, My name is MD. Musfiqur Rahman</h6>
								<h2 class="text-uppercase text-warning">I'm A Web Stack Developer</h2>
								
								<button class="btn btn-dark bg-info">My Work</button>
								<button class="btn btn-dark bg-info">Hire Me</button>
								
							</div>
						<!-- Person part-->	 
						<div class="col-6">
							<img src="images/mypic.jpg" class="img-fluid rounded float-right" alt="mypic">
						</div>
						</div>
					</div>
				</div>
			     
			</section>
				<!-- About me part-->
			<section id="about" class="p-5">
				<!-- About me content-->
				<div class="container">
					<div class="row">
						<div class="col-12 m-0 p-0 text-center pt-5">
							<h6 class="text-uppercase m-0 pb-2 text-info" >About Me</h6>
							<h1  class="text-uppercase text-dark pb-3">Welcome To My WebSite</h1>
							<p class="pb-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
							Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
							when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
							It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
							It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently 
							with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
						</div>
					</div>
					
						<div class="row mt-5">
							<!-- progress part-->
							<!--progress content-->
							<div class="col-md-4 p-2">
								<p class="m-0">Web Design</p>
								<!-- progress bar part-->
								<div class="progress">
									<div class="progress-bar bg-success" style="width:80%"></div>
								</div>
							</div>
							<div class="col-md-4 p-2">
								<p class="m-0">PHP Development</p>
									 <!-- progress bar part-->
								<div class="progress">
									<div class="progress-bar bg-warning" style="width:75%"></div>
								</div>
							</div>		 
							<div class="col-md-4 p-2">
								<p class="m-0">SEO</p>
								<!-- progress bar part-->
								<div class="progress">
									<div class="progress-bar bg-danger" style="width:55%"></div>
								</div>
							</div>			 
							<div class="col-md-4 p-2">
								<p class="m-0">Marketing</p>
								<!-- progress bar part-->
								<div class="progress">
									<div class="progress-bar bg-warning" style="width:65%"></div>
								</div>
							</div>
							<div class="col-md-4 p-2">
								<p class="m-0">Photography</p>
								<!-- progress bar part-->
								<div class="progress">
									<div class="progress-bar bg-primary" style="width:70%"></div>	
								</div>
							</div>		 
							<div class="col-md-4 p-2">
								<p class="m-0">Branding</p>
								<!-- progress bar part-->
								<div class="progress">
									<div class="progress-bar bg-success" style="width:60%"></div>	
								</div>
							</div>
						</div>
				</div>
			</section>
			<!-- Services part-->
			<section id="sevice">
				<div class="container">
					<div class="row mt-5 ">
					<div class="col-12 p-0 m-0 text-center">
						<h6 class="mt-5 text-info text-uppercase">My Services</h6>
						<h1 class="pt-2 text-white text-uppercase">What I Do</h1>
						<!-- Services content-->
					</div>	
					</div>	
						<div class="row pt-5">
							<!-- Services 01-->
							<div class="col-md-4 mb-2">
								<div class="card text-center py-5 text-white custom-card">
								<div class="card-body">
									<i class="far fa-list-alt text-warning"></i>
									<h3 class="card-title py-3 text-uppercase">Professional Code</h3>
									<p class="card-text ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
									Lorem Ipsum has been the industry's standard dummy text </p>
								 </div>
								</div>
							</div>
							<!-- Services 02-->
							<div class="col-md-4 mb-2">
								<div class="card text-center py-5 text-white custom-card">
								<div class="card-body">
									<i class="far fa-lightbulb text-warning"></i>
									<h3 class="card-title py-3 text-uppercase">Creative Ideas</h3>
									<p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
									Lorem Ipsum has been the industry's standard dummy text </p>
								 </div>
								</div>
							</div>
							<!-- Services 03-->
							<div class="col-md-4 mb-2">
								<div class="card text-center py-5 text-white custom-card">
								<div class="card-body">
									<i class="far fa-clone text-warning"></i>
									<h3 class="card-title py-3 text-uppercase">SEO & Marketing</h3>
									<p class="card-text ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
									Lorem Ipsum has been the industry's standard dummy text </p>
								 </div>
								</div>
							</div>
							<!-- Services 04-->
							<div class="col-md-4 mb-2">
								<div class="card text-center py-5 text-white custom-card">
								<div class="card-body">
									<i class="far fa-heart text-warning"></i>
									<h3 class="card-title py-3 text-uppercase">User Friendly</h3>
									<p class="card-text ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
									Lorem Ipsum has been the industry's standard dummy text </p>
								 </div>
								</div>
							</div>
							<!-- Services 05-->
							<div class="col-md-4 mb-2">
								<div class="card text-center py-5 text-white custom-card">
								<div class="card-body">
									<i class="fas fa-magic text-warning"></i>
									<h3 class="card-title py-3 text-uppercase">Web Development</h3>
									<p class="card-text ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
									Lorem Ipsum has been the industry's standard dummy text </p>
								 </div>
								</div>
							</div>
							<!-- Services 06-->
							<div class="col-md-4 mb-2">
								<div class="card text-center py-5 text-white custom-card">
								<div class="card-body">
									<i class="fas fa-sliders-h text-warning"></i>
									<h3 class="card-title py-3 text-uppercase">Portfolio Options</h3>
									<p class="card-text ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
									Lorem Ipsum has been the industry's standard dummy text </p>
								 </div>
								</div>
							</div>
						</div>
					</div>	
				</div>		 
			</section>
			<!-- Portfolio part-->
			<section id="projects" class="py-5">
			    <div class="container">
					<div class="row mt-5">
					<div class="col-12 p-0 m-0 text-center">
						<h6 class="text-info text-uppercase">View All</h6>
						<h1 class="pt-2 text-dark text-uppercase">My Projects</h1>
					</div>
					</div>
					<!-- Portfolio content--> 
					<div class="row">
						<!-- Portfolio 01-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p1.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 02-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p2.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 03-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p3.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 04-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p4.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 05-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p5.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 06-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p6.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 07-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p7.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 08-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p8.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
						<!-- Portfolio 09-->
						<div class="col-md-4 mb-2">
							<div class="card">	
								<img src="images/p9.jpg" class="caed-img img-fluid" alt="project1">
								<div class="card-img-overlay">
									<button class="btn-dark btn-block align-self-center projects-button">View</button>
								</div>
						    </div>
					    </div>
					</div>
				</div>
			</section>
			<!-- Review part-->
			<section id="review" class="py-5">
				<div class="container">
					<div class="row text-center">
						<!-- Countdown content-->
						<div class="col-md-3 col-6"> <!-- Countdown part 01-->
							<i class="far fa-lightbulb text-warning"></i>
							<h3 class="text-white">48</h3>
							<h5 class="text-white text-uppercase">Project Done</h5>
						</div>
						<div class="col-md-3 col-6"> <!-- Countdown part 02-->
							<i class="far fa-heart text-warning"></i>
							<h3 class="text-white">42</h3>
							<h5 class="text-white text-uppercase">Satisfied Clints</h5>
						</div>
						<div class="col-md-3 col-6"> <!-- Countdown part 03-->
							<i class="fas fa-magic text-warning"></i>
							<h3 class="text-white">86</h3>
							<h5 class="text-white text-uppercase">Awards</h5>
						</div>
						<div class="col-md-3 col-6"> <!-- Countdown part 04-->
							<i class="far fa-smile-beam text-warning"></i>
							<h3 class="text-white">78</h3>
							<h5 class="text-white text-uppercase">Happy Clints</h5>
						</div>
					</div>
				</div>			
			</section>
			<!-- Contact me part-->
			<section id="contact" class="py-5">
				<div class="container">
					<div class="row">
						<div class="col-12 p-0 m-0 text-center">
							<h6 class="text-info text-uppercase">Find Me</h6>
							<h1 class="pt-2 text-white text-uppercase">Contact Me Now</h1>
						</div>
					</div>
					<form action="email.php" name="contactForm" class="text-center" onsubmit="if(confirm('Do you want to submit It?'))
					     { if(myvalidation()== false){ return false; }}else{event.preventDefault(); return false;}">
						<div class="form-row">
							<div class="col-md-6 col-12">
								<input name="name" type="text" class="form-control mb-2" placeholder="Enter Your Name">
								<span id="name-error"></span>
								<input name="email" type="text" class="form-control mb-2" placeholder="Enter Your Email">
								<span id="email-error"></span>
								<input name="phone" type="text" class="form-control mb-2" placeholder="Enter Your Phone">
								<span id="phone-error"></span>
							</div>
							<div class="col-md-6 col-12">
								<textarea name="message" class="form-control h-100" placeholder="Enter Your Message"></textarea>
								<span id="message-error"></span>
							</div>
						</div>
						<div style="width:100%; clear:both;">
						<input type="submit" name="emailAction" value="Submit" class="btn btn-primary mt-5">
						</div>
					</form>
						<!-- Address part -->
						<div class="row py-5">
							<div class="col-12 col-md-4 text-center">
								<i class="far fa-address-card text-warning"></i>
								<p class="text-white">Address <br> Firmgate,Dhaka-1207</p>
							</div>
							<div class="col-12 col-md-4 text-center">
								<i class="fas fa-at text-warning"></i>
								<p class="text-white">Email <br> musfiq0909@gmail.com</p>
							</div>
							<div class="col-12 col-md-4 text-center">
								<i class="fas fa-phone text-warning"></i>
								<p class="text-white">Phone <br>+01234567891</p>
							</div>
						</div>
				</div>
			</section>
		</main>
		<footer>
			<!-- copyright part -->
			<div class="container">
				<div class="row text-center">
					<div class="col-md-6 col-12 mb-2 text-white" >
						&copy; 2019 All Right Riserved By Musfiqur Rahman <a class="text-warning" href="registration.php">Registration Here</a>
					</div>
				
					<div id="social" class="col-md-6 col-12">
					
							<a href="#"><i class="fab fa-facebook-square text-warning px-3"></i></a>
							<a href="#"><i class="fab fa-twitter-square text-warning px-3"></i></a>
							<a href="#"><i class="fab fa-google-plus-g text-warning px-3"></i></a>
							<a href="#"><i class="fab fa-linkedin text-warning px-3"></i></a>
		
					</div>
				</div>
			</div>
			<div id="upper">
				<i class="fas fa-arrow-alt-circle-up"></i>
			</div>
			
		</footer>
		<script>
			
		</script>
		
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.3.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
		
		
		
    </body>
	 
	 
</html>